﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // hej
            //entry point, programmet starter her
            // indtast noget input
            Console.Write("Indtast pris ");
            string priStr = Console.ReadLine();
            int pris = Convert.ToInt32(priStr);

            Console.Write("Indtast betaling ");
            string betStr = Console.ReadLine();
            int betaling = Convert.ToInt32(betStr);


            // beregninger
            int forskel = betaling - pris;

            int rest = forskel % 20;

            //uddata
            Console.WriteLine("rest beløb: " + forskel);
            Console.WriteLine("rest beløb: " + rest);
            Console.ReadLine();


        }
    }
}
